from tkinter import *
from tkinter.filedialog import askopenfilename
from PIL import Image, ImageTk, ImageDraw, ImageFont
import cv2
import numpy as np


root = Tk()
root.config()
root.title('测一测')
matching_photo = PhotoImage(file='matching photo.png')
my_phono = PhotoImage(file='select.png')
capture_button = PhotoImage(file='capture button.png')
select_button = PhotoImage(file='select button.png')
start_button = PhotoImage(file='start matching.png')
tips_photo = PhotoImage(file='tips.png')

img_ori = None

def TK_image(img):
    # 重新排列颜色通道
    b, g, r = cv2.split(img)
    img = cv2.merge((r, g, b))
    # 将Image对象转换为TkPhoto对象
    im = Image.fromarray(img)
    imgtk = ImageTk.PhotoImage(image=im)
    return imgtk

def find_face(ims):
    # 实例化人脸分类器
    face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_alt.xml')
    # 将原彩色图转换成灰度图
    gray = cv2.cvtColor(ims, cv2.COLOR_BGR2GRAY)
    # 开始在灰度图上检测人脸，输出是人脸区域的外接矩形框
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=1)
    # 遍历人脸检测结果
    for (x, y, w, h) in faces:
        # 调整原矩形框截取图像
        x = int(x - w / 4)
        y = int(y - h / 3)
        w = int(w + w / 2)
        h = int(h + h / 2)
        face_img = ims[y:y + h, x:x + w]
    return face_img

def cv2AddChineseText(img, text, position, textColor=(0, 255, 0), textSize=30):
    if (isinstance(img, np.ndarray)):  # 判断是否OpenCV图片类型
        img = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    # 创建一个可以在给定图像上绘图的对象
    draw = ImageDraw.Draw(img)
    # 字体的格式
    fontStyle = ImageFont.truetype(
        "simsun.ttc", textSize, encoding="utf-8")
    # 绘制文本
    draw.text(position, text, textColor, font=fontStyle)
    # 转换回OpenCV格式
    return cv2.cvtColor(np.asarray(img), cv2.COLOR_RGB2BGR)

class GUI():
    def __init__(self):
        self.title = Label(root, text="测一测你和哪个明星最相似？", fg="black", font=('华文行楷', 29))
        self.title.pack()
        # 输出照片
        self.photo_star = Label(root, image=matching_photo)
        self.photo_star.place(x=50, y=60)
        # 输入照片
        self.select = Label(root, image=my_phono)
        self.select.place(x=620, y=60)
        # 相似度检测结果
        self.text = Label(root, width=70, height=8, bd=0, bg='White')
        self.text.place(x=50, y=600)
        self.photo_tips = Label(root, image=tips_photo)
        self.photo_tips.place(x=620, y=600)

        # 选择照片按钮
        self.button_chose1 = Button(root, image=select_button, bd=0,
                                    command=lambda: self.chose_file())
        self.button_chose1.place(x=1200, y=60)
        # 拍摄照片按钮
        self.button_chose2 = Button(root, image=capture_button, bd=0,
                                    command=lambda: self.chose_cam())
        self.button_chose2.place(x=1200, y=190)
        # 开始测试按钮
        self.button_chose2 = Button(root, image=start_button, bd=0,
                                    command=lambda: self.matching())
        self.button_chose2.place(x=1200, y=320)

        self.file = None
        self.camera_break = 0

    def chose_file(self, event=None):
        # 设置全局变量
        global img_ori
        # 选择图片，传出地址
        filename = askopenfilename(title='选择图片', filetypes=[(('JPG', '*.jpg')), ('All Files', '*')])
        ims = cv2.imread(filename)
        self.file = ims.copy()
        # 识别人脸，并裁剪照片
        img = find_face(ims)
        scale_image = cv2.resize(img, (500, 500), interpolation=cv2.INTER_CUBIC)
        # 转换图片格式
        img_ori = TK_image(scale_image)
        lb1 = Label(self.select, image=img_ori)
        lb1.place(x=0, y=0)

    def chose_cam(self, event=None):
        global img_ori
        cap = cv2.VideoCapture(0)

        while (cap.isOpened()):
            # 逐帧捕获
            ret, frame = cap.read()
            frame = cv2AddChineseText(frame, '点击"s"键拍摄照片，点击"q"键关闭摄像头', (10, 10), (255, 0, 0), 20)
            if ret == True:
                # 获取彩色图像
                frame = cv2.cvtColor(frame, cv2.IMREAD_COLOR)
                # 显示结果帧
                cv2.imshow('frame', frame)
                # 当按下c键保存图片output.jpg
                if cv2.waitKey(1) == ord('s'):
                    cv2.imwrite('output.jpg', frame)
                    ims = cv2.imread('output.jpg')
                    self.file = ims.copy()
                    # 识别人脸，并裁剪照片
                    img = find_face(ims)
                    scale_image = cv2.resize(img, (500, 500), interpolation=cv2.INTER_CUBIC)
                    # 转换图片格式
                    img_ori = TK_image(scale_image)
                    lb1 = Label(self.select, image=img_ori)
                    lb1.place(x=0, y=0)
                # 当按下q键退出
                elif cv2.waitKey(1) == ord('q'):
                    break
            else:
                break
        # 当一切都完成后，释放捕获
        cap.release()
        cv2.destroyAllWindows()

    def matching(self, event=None):
        global img_ori
        root.update()
        img_ori = None
        self.file = None
        self.camera_break = 1
        self.select.update()



cf = GUI()
root.geometry('1280x720+{0}+{1}'.format(0, 0))
root.mainloop()

